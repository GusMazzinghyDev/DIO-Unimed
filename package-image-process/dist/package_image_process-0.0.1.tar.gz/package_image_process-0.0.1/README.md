# package_image_process

Description. 
The package image_processing is used to:
	Processing:
		- Histogram matching 
		- Structural similarity
		- Resize image
	Utils:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histogram 

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_image_process

```bash
pip install package_image_process
```

<!-- ## Usage

```python
from package_image_process.module1_gusmazzinghy import file1_gusmazzinghy
file1_gusmazzinghy.my_function()
``` -->

## Author
gusmazzinghy

## License
[MIT](https://choosealicense.com/licenses/mit/)